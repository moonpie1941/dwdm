import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from scipy.cluster.hierarchy import dendrogram, linkage, fcluster
from scipy.spatial.distance import pdist, squareform
from sklearn.metrics import adjusted_rand_score

# Step 1: Load CSV file into a pandas DataFrame
df = pd.read_csv('dataset.csv')

# Step 2: Select the first 100 entries
df = df.head(10)

# Step 3: Preprocess data (considering 'Sequence_len' for clustering)
sequence_lengths = df['Sequence_len'].values.reshape(-1, 1)

# Standardize the data
scaler = StandardScaler()
scaled_data = scaler.fit_transform(sequence_lengths)

# Step 4: Perform hierarchical clustering using Ward's method
Z = linkage(scaled_data, method='ward')

# Step 5: Set a threshold for defining clusters
threshold_distance = 7  # Adjust as necessary
clusters = fcluster(Z, threshold_distance, criterion='distance')

# Step 6: Cluster stability analysis using bootstrapping
def bootstrap_clustering(data, num_samples=100, threshold_distance=7):
    n = len(data)
    original_labels = fcluster(linkage(data, method='ward'), threshold_distance, criterion='distance')
    stability_scores = []

    for _ in range(num_samples):
        indices = np.random.choice(range(n), size=n, replace=True)
        resampled_data = data[indices]
        resampled_labels = fcluster(linkage(resampled_data, method='ward'), threshold_distance, criterion='distance')
        ari = adjusted_rand_score(original_labels[indices], resampled_labels)
        stability_scores.append(ari)

    return np.mean(stability_scores), np.std(stability_scores)

# Step 7: Run the bootstrap analysis for cluster stability
mean_stability, std_stability = bootstrap_clustering(scaled_data)

# Step 8: Display the dendrogram with cluster assignments
plt.figure(figsize=(14, 8))
dendro = dendrogram(Z, labels=df['ID'].values, leaf_rotation=90, leaf_font_size=10, color_threshold=threshold_distance)
plt.axhline(y=threshold_distance, color='r', linestyle='--', label=f'Threshold: {threshold_distance}')
plt.title("Dendrogram with Cluster Stability Analysis")
plt.xlabel('Organism ID')
plt.ylabel('Distance')
plt.legend()

# Step 9: Add stability analysis results to the dendrogram
plt.figtext(0.15, 0.8, f'Mean Stability (ARI): {mean_stability:.2f}\nStd Deviation: {std_stability:.2f}', fontsize=10)

# Step 10: Create a heatmap for pairwise distances between sequences
plt.figure(figsize=(12, 10))
distance_matrix = pdist(scaled_data, metric='euclidean')
distance_squareform = squareform(distance_matrix)

# Plot heatmap
sns.heatmap(distance_squareform, cmap='viridis', xticklabels=df['ID'].values, yticklabels=df['ID'].values, cbar_kws={'label': 'Distance'})
plt.title('Heatmap of Pairwise Distances Between Sequences')
plt.xlabel('Organism ID')
plt.ylabel('Organism ID')

# Show both plots
plt.show()
