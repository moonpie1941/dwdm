drop database DWDM;
create database DWDM;
use DWDM;
-- Customer Table
CREATE TABLE Customer (
    CustomerID INT PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    Email VARCHAR(100),
    PhoneNumber VARCHAR(20),
    RegistrationDate DATE,
    ShippingAddress VARCHAR(100),
    ShippingCity VARCHAR(50)
);

-- Order Table
CREATE TABLE `Order` (
    OrderID INT PRIMARY KEY,
    CustomerID INT,
    OrderDate DATE,
    ShipDate DATE,
    RequestedShippingDate DATE,
    TotalAmount DECIMAL(10, 2),
    TrackingNumber VARCHAR(50),
    FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID)
);

-- Product Table
CREATE TABLE Product (
    ProductID INT PRIMARY KEY,
    SupplierID INT,
    ProductName VARCHAR(100),
    DateAdded DATE,
    Weight DECIMAL(10, 2)
);

-- Sales Representatives Table
CREATE TABLE SalesRepresentatives (
    SalesRepresentativeID INT PRIMARY KEY,
    Name VARCHAR(100),
    PhoneNumber VARCHAR(20),
    Department VARCHAR(50),
    TotalSales DECIMAL(10, 2),
    Performance VARCHAR(50)
);

-- Sales Table
CREATE TABLE Sales (
    SalesID INT PRIMARY KEY,
    SalesRepresentativeID INT,
    CustomerID INT,
    OrderID INT,
    DealValue DECIMAL(10, 2),
    SalesDate DATE,
    FOREIGN KEY (SalesRepresentativeID) REFERENCES SalesRepresentatives(SalesRepresentativeID),
    FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID),
    FOREIGN KEY (OrderID) REFERENCES `Order`(OrderID)
);


-- Fact Table
CREATE TABLE Fact (
    CustomerID INT,
    OrderID INT,
    ProductID INT,
    SalesID INT,
    PRIMARY KEY (CustomerID, OrderID, ProductID, SalesID),
    FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID),
    FOREIGN KEY (OrderID) REFERENCES `Order`(OrderID),
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    FOREIGN KEY (SalesID) REFERENCES Sales(SalesID)
);
-- Insert data into Customer Table
INSERT INTO Customer (CustomerID, FirstName, LastName, Email, PhoneNumber, RegistrationDate, ShippingAddress, ShippingCity) VALUES
(1, 'John', 'Doe', 'john.doe@example.com', '123-456-7890', '2024-01-01', '123 Elm St', 'New York'),
(2, 'Jane', 'Smith', 'jane.smith@example.com', '123-456-7891', '2024-01-02', '456 Oak St', 'Los Angeles'),
(3, 'Alice', 'Johnson', 'alice.johnson@example.com', '123-456-7892', '2024-01-03', '789 Pine St', 'Chicago');

-- Insert data into Order Table
INSERT INTO `Order` (OrderID, CustomerID, OrderDate, ShipDate, RequestedShippingDate, TotalAmount, TrackingNumber) VALUES
(1, 1, '2024-01-10', '2024-01-15', '2024-01-14', 150.00, 'TRACK123'),
(2, 2, '2024-01-11', '2024-01-16', '2024-01-15', 200.00, 'TRACK124'),
(3, 3, '2024-01-12', '2024-01-17', '2024-01-16', 250.00, 'TRACK125');

-- Insert data into Product Table
INSERT INTO Product (ProductID, SupplierID, ProductName, DateAdded, Weight) VALUES
(1, 101, 'Product A', '2024-01-05', 1.5),
(2, 102, 'Product B', '2024-01-06', 2.0),
(3, 103, 'Product C', '2024-01-07', 2.5);

-- Insert data into Sales Representatives Table
INSERT INTO SalesRepresentatives (SalesRepresentativeID, Name, PhoneNumber, Department, TotalSales, Performance) VALUES
(1, 'Michael Brown', '123-456-7893', 'Electronics', 1000.00, 'Excellent'),
(2, 'Laura Wilson', '123-456-7894', 'Home & Kitchen', 1500.00, 'Good'),
(3, 'David Martinez', '123-456-7895', 'Sports', 2000.00, 'Outstanding');

-- Insert data into Sales Table
INSERT INTO Sales (SalesID, SalesRepresentativeID, CustomerID, OrderID, DealValue, SalesDate) VALUES
(1, 1, 1, 1, 150.00, '2024-01-10'),
(2, 2, 2, 2, 200.00, '2024-01-11'),
(3, 3, 3, 3, 250.00, '2024-01-12');

-- Insert data into Fact Table
INSERT INTO Fact (CustomerID, OrderID, ProductID, SalesID) VALUES
(1, 1, 1, 1),
(2, 2, 2, 2),
(3, 3, 3, 3);

SELECT
    C.CustomerID,
    CONCAT(C.FirstName, ' ', C.LastName) AS CustomerName,
    P.ProductName,
    SUM(O.TotalAmount) AS NetOrderAmount,
    SR.Name AS SalesRepresentativeName,
    SR.Performance
FROM
    Fact F
JOIN
    Customer C ON F.CustomerID = C.CustomerID
JOIN
    `Order` O ON F.OrderID = O.OrderID
JOIN
    Product P ON F.ProductID = P.ProductID
JOIN
    Sales S ON F.SalesID = S.SalesID
JOIN
    SalesRepresentatives SR ON S.SalesRepresentativeID = SR.SalesRepresentativeID
GROUP BY
    C.CustomerID, CustomerName, P.ProductName, SalesRepresentativeName, SR.Performance;

SELECT 
    SUM(TableSizeInBytes) AS TotalSizeInBytes,
    SUM(TableSizeInBytes) / 1024 AS TotalSizeInKB,
    SUM(TableSizeInBytes) / 1024 / 1024 AS TotalSizeInMB
FROM (
    -- Customer Table
    SELECT
        'Customer' AS TableName,
        (3 + (200 * 5)) AS RecordCount, -- 5 years of customer growth
        ((3 + (200 * 5)) * (
            4 + 25 + 25 + 50 + 15 + 3 + 50 + 25 -- Adjusted field sizes
        )) * 1.1 AS TableSizeInBytes -- Add 10% overhead
    UNION ALL
    -- Order Table
    SELECT
        'Order' AS TableName,
        ((3 + (200 * 5)) * 5) AS RecordCount, -- 5 years of orders per customer
        (((3 + (200 * 5)) * 5) * (
            4 + 4 + 3 + 3 + 3 + 8 + 25 -- Adjusted field sizes
        ) + ((3 + (200 * 5)) * 5 * 20)) * 1.1 AS TableSizeInBytes -- Include index overhead
    UNION ALL
    -- Product Table
    SELECT
        'Product' AS TableName,
        (3 + (10 * 5)) AS RecordCount, -- 5 years of new products
        ((3 + (10 * 5)) * (
            4 + 4 + 50 + 3 + 8 -- Adjusted field sizes
        )) * 1.1 AS TableSizeInBytes
    UNION ALL
    -- SalesRepresentatives Table
    SELECT
        'SalesRepresentatives' AS TableName,
        (3 + (1 * 5)) AS RecordCount, -- 5 years of new representatives
        ((3 + (1 * 5)) * (
            4 + 50 + 15 + 25 + 8 + 25 -- Adjusted field sizes
        )) * 1.1 AS TableSizeInBytes
    UNION ALL
    -- Sales Table
    SELECT
        'Sales' AS TableName,
        ((3 + (200 * 5)) * 5) AS RecordCount, -- Matches order count
        (((3 + (200 * 5)) * 5) * (
            4 + 4 + 4 + 4 + 8 + 3 -- Adjusted field sizes
        ) + ((3 + (200 * 5)) * 5 * 15)) * 1.1 AS TableSizeInBytes -- Include index overhead
    UNION ALL
    -- Fact Table
    SELECT
        'Fact' AS TableName,
        ((3 + (200 * 5)) * 5 * 3) AS RecordCount, -- Assume 3 products per order
        (((3 + (200 * 5)) * 5 * 3) * (
            4 + 4 + 4 + 4 -- Adjusted field sizes
        ) + ((3 + (200 * 5)) * 5 * 3 * 30)) * 1.1 AS TableSizeInBytes -- Composite PK index overhead
) AS Sizes;
