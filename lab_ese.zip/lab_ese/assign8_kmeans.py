import numpy as np
import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

# Load the wine dataset
wine = datasets.load_wine()
X = wine.data

# Scale the features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Calculate WCSS (within-cluster sum of squares) for the Elbow method
wcss = []
for k in range(1, 11):
    kmeans = KMeans(n_clusters=k, random_state=42)
    kmeans.fit(X_scaled)
    wcss.append(kmeans.inertia_)

# Plot the Elbow graph to determine the optimal number of clusters
plt.figure(figsize=(8, 6))
plt.plot(range(1, 11), wcss, marker='o', linestyle='--')
plt.title('Elbow Graph for Optimal Clusters')
plt.xlabel('Number of Clusters')
plt.ylabel('WCSS')
plt.xticks(np.arange(1, 11, step=1))
plt.grid(True)
plt.show()

# Apply K-Means clustering with the optimal number of clusters (e.g., 3)
kmeans = KMeans(n_clusters=3, random_state=42)
kmeans.fit(X_scaled)

# Retrieve the centroids and labels
centroids = kmeans.cluster_centers_
labels = kmeans.labels_

# Reduce dimensions to 2D using PCA for visualization
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)

# Plot the clusters and centroids
plt.figure(figsize=(8, 6))
plt.scatter(X_pca[:, 0], X_pca[:, 1], c=labels, cmap='viridis', marker='o')
plt.scatter(pca.transform(centroids)[:, 0], pca.transform(centroids)[:, 1], s=300, c='red', label='Centroids')
plt.title('K-Means Clustering on Wine Dataset')
plt.legend()
plt.show()
