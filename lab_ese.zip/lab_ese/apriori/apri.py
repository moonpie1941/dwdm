import pandas as pd
from apyori import apriori
import numpy as np

# Step 1: Load the dataset
df = pd.read_csv(r"E:\\SEM 5\\DWDM\\Apriori\\store_data.csv")

# Step 2: Pre-process the dataset
# Convert all columns to strings to ensure compatibility with the apriori algorithm
df = df.astype(str)

# Replace NaN values with empty strings
df.fillna('', inplace=True)

# Convert the DataFrame to a list of transactions (each transaction is a list of items)
transactions = df.values.tolist()

# Remove empty strings and 'nan' values from the transactions
transactions = [[item for item in transaction if item != '' and item.lower() != 'nan'] for transaction in transactions]

# Adjusted parameters
min_support = 0.02  # Lowered from 0.1
min_confidence = 0.4  # Lowered from 0.5

# Step 3: Apply the Apriori algorithm
association_rules = apriori(transactions, min_support=min_support, min_confidence=min_confidence, min_lift=1.2, min_length=2)
association_results = list(association_rules)

# Print the number of association rules found
print(f"Number of association rules found: {len(association_results)}")

# Display the found association rules
if association_results:
    print("Association Rules:")
    for item in association_results:
        pair = item[0]
        items = [x for x in pair]
        support = item[1]
        # Confidence and Lift are calculated from the item[2] structure
        confidence = item[2][0][2] if len(item[2]) > 0 else 0
        lift = item[2][0][3] if len(item[2]) > 0 else 0
        
        print(f"Rule: {items[0]} -> {items[1]}")
        print(f"Support: {support}")
        print(f"Confidence: {confidence}")
        print(f"Lift: {lift}")
        print("--------------------------------------------")
else:
    print("No rules found. Check the variety and quantity of items in your transactions.")