drop database srushti;
create database srushti;
use srushti;
-- Create Dimension Tables
CREATE TABLE DimBookType (
    book_type_id INT AUTO_INCREMENT PRIMARY KEY,
    book_type_name VARCHAR(100)
);

CREATE TABLE DimLocation (
    location_id INT AUTO_INCREMENT PRIMARY KEY,
    location_name VARCHAR(100)
);

CREATE TABLE DimAuthor (
    author_id INT AUTO_INCREMENT PRIMARY KEY,
    author_name VARCHAR(100),
    author_age INT,
    author_country VARCHAR(100)
);

CREATE TABLE DimPublication (
    publication_id INT AUTO_INCREMENT PRIMARY KEY,
    publication_name VARCHAR(100),
    publication_country VARCHAR(100),
    publication_year INT
);

-- Create Fact Table
CREATE TABLE FactBookSales (
    fact_id INT AUTO_INCREMENT PRIMARY KEY,
    book_type_id INT,
    location_id INT,
    author_id INT,
    publication_id INT,
    quantity INT,
    profit DECIMAL(10, 2),
    FOREIGN KEY (book_type_id) REFERENCES DimBookType(book_type_id),
    FOREIGN KEY (location_id) REFERENCES DimLocation(location_id),
    FOREIGN KEY (author_id) REFERENCES DimAuthor(author_id),
    FOREIGN KEY (publication_id) REFERENCES DimPublication(publication_id)
);

-- Insert into DimBookType
INSERT INTO DimBookType (book_type_name) VALUES 
('Fiction'), 
('Non-Fiction'), 
('Science'), 
('Technology');

-- Insert into DimLocation
INSERT INTO DimLocation (location_name) VALUES 
('New York'), 
('Los Angeles'), 
('Chicago'), 
('Houston');

-- Insert into DimAuthor
INSERT INTO DimAuthor (author_name, author_age, author_country) VALUES 
('John Doe', 45, 'USA'), 
('Jane Smith', 38, 'UK'), 
('Carlos Ruiz', 50, 'Spain'), 
('Yuki Tanaka', 42, 'Japan');

-- Insert into DimPublication
INSERT INTO DimPublication (publication_name, publication_country, publication_year) VALUES 
('Penguin Books', 'USA', 1995), 
('HarperCollins', 'UK', 1980), 
('Random House', 'Germany', 2005), 
('Shueisha', 'Japan', 1988);

-- Insert into FactBookSales
INSERT INTO FactBookSales (book_type_id, location_id, author_id, publication_id, quantity, profit) VALUES 
(1, 1, 1, 1, 150, 3000.00),
(2, 2, 2, 2, 200, 5000.00),
(3, 3, 3, 3, 100, 2500.00),
(4, 4, 4, 4, 50, 1500.00);

SELECT 
    b.book_type_name, 
    SUM(f.quantity) AS total_quantity, 
    SUM(f.profit) AS total_profit
FROM 
    FactBookSales f
JOIN 
    DimBookType b ON f.book_type_id = b.book_type_id
GROUP BY 
    b.book_type_name;
    
    
    SELECT 
    l.location_name, 
    SUM(f.quantity) AS total_quantity, 
    SUM(f.profit) AS total_profit
FROM 
    FactBookSales f
JOIN 
    DimLocation l ON f.location_id = l.location_id
GROUP BY 
    l.location_name;
    
    
    SELECT 
    a.author_name, 
    SUM(f.quantity) AS total_quantity, 
    SUM(f.profit) AS total_profit
FROM 
    FactBookSales f
JOIN 
    DimAuthor a ON f.author_id = a.author_id
GROUP BY 
    a.author_name;