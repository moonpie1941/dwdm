drop database ass5;
create database ass5;
use ass5;
-- Creating Dimension Tables
CREATE TABLE Patient_Dimension (
    Patient_ID INT PRIMARY KEY,
    Name VARCHAR(100),
    Age INT,
    Gender CHAR(1),
    Address VARCHAR(255),
    Medical_History TEXT
);

CREATE TABLE Provider_Dimension (
    Provider_ID INT PRIMARY KEY,
    Name VARCHAR(100),
    Specialty VARCHAR(100),
    Department VARCHAR(100),
    Contact_Info VARCHAR(100)
);

CREATE TABLE Appointment_Dimension (
    Appointment_ID INT PRIMARY KEY,
    Date DATE,
    Time TIME,
    Type VARCHAR(50)
);

CREATE TABLE Diagnosis_Dimension (
    Diagnosis_ID INT PRIMARY KEY,
    Code VARCHAR(10),
    Description VARCHAR(255)
);

CREATE TABLE Treatment_Dimension (
    Treatment_ID INT PRIMARY KEY,
    Description VARCHAR(255),
    Treatment_Type VARCHAR(50)
);

CREATE TABLE Drug_Dimension (
    Drug_ID INT PRIMARY KEY,
    Name VARCHAR(100),
    Category VARCHAR(50),
    Cost DECIMAL(10, 2),
    Stock_Level INT
);

CREATE TABLE Insurance_Dimension (
    Insurance_ID INT PRIMARY KEY,
    Company_Name VARCHAR(100),
    Plan_Type VARCHAR(50),
    Coverage_Percentage DECIMAL(5, 2)
);

-- Creating Fact Tables
CREATE TABLE Patient_Visit_Fact (
    Visit_ID INT PRIMARY KEY,
    Patient_ID INT,
    Provider_ID INT,
    Appointment_ID INT,
    Diagnosis_ID INT,
    Treatment_ID INT,
    Visit_Duration INT,
    Patient_Charges DECIMAL(10, 2),
    FOREIGN KEY (Patient_ID) REFERENCES Patient_Dimension(Patient_ID),
    FOREIGN KEY (Provider_ID) REFERENCES Provider_Dimension(Provider_ID),
    FOREIGN KEY (Appointment_ID) REFERENCES Appointment_Dimension(Appointment_ID),
    FOREIGN KEY (Diagnosis_ID) REFERENCES Diagnosis_Dimension(Diagnosis_ID),
    FOREIGN KEY (Treatment_ID) REFERENCES Treatment_Dimension(Treatment_ID)
);

CREATE TABLE Billing_Fact (
    Billing_ID INT PRIMARY KEY,
    Patient_ID INT,
    Provider_ID INT,
    Insurance_ID INT,
    Billed_Amount DECIMAL(10, 2),
    Paid_Amount DECIMAL(10, 2),
    Payment_Date DATE,
    FOREIGN KEY (Patient_ID) REFERENCES Patient_Dimension(Patient_ID),
    FOREIGN KEY (Provider_ID) REFERENCES Provider_Dimension(Provider_ID),
    FOREIGN KEY (Insurance_ID) REFERENCES Insurance_Dimension(Insurance_ID)
);

CREATE TABLE Pharmacy_Fact (
    Prescription_ID INT PRIMARY KEY,
    Patient_ID INT,
    Provider_ID INT,
    Drug_ID INT,
    Medication_Cost DECIMAL(10, 2),
    Quantity INT,
    FOREIGN KEY (Patient_ID) REFERENCES Patient_Dimension(Patient_ID),
    FOREIGN KEY (Provider_ID) REFERENCES Provider_Dimension(Provider_ID),
    FOREIGN KEY (Drug_ID) REFERENCES Drug_Dimension(Drug_ID)
);

INSERT INTO Patient_Dimension (Patient_ID, Name, Age, Gender, Address, Medical_History)
VALUES 
(1, 'John Doe', 45, 'M', '123 Main St, Springfield', 'Hypertension'),
(2, 'Jane Smith', 32, 'F', '456 Oak St, Shelbyville', 'Asthma'),
(3, 'Alice Johnson', 28, 'F', '789 Maple Ave, Capital City', 'None');

INSERT INTO Provider_Dimension (Provider_ID, Name, Specialty, Department, Contact_Info)
VALUES 
(1, 'Dr. Emily Brown', 'Cardiologist', 'Cardiology', '555-1234'),
(2, 'Dr. Michael Green', 'Pulmonologist', 'Pulmonary Medicine', '555-5678'),
(3, 'Dr. Sarah White', 'General Practitioner', 'Primary Care', '555-9012');

INSERT INTO Appointment_Dimension (Appointment_ID, Date, Time, Type)
VALUES 
(1, '2024-09-01', '09:30:00', 'Consultation'),
(2, '2024-09-02', '11:00:00', 'Follow-up'),
(3, '2024-09-03', '14:00:00', 'Surgery');

INSERT INTO Diagnosis_Dimension (Diagnosis_ID, Code, Description)
VALUES 
(1, 'I10', 'Essential Hypertension'),
(2, 'J45', 'Asthma'),
(3, 'Z00', 'General Medical Examination');

INSERT INTO Treatment_Dimension (Treatment_ID, Description, Treatment_Type)
VALUES 
(1, 'Prescribed Lisinopril', 'Medication'),
(2, 'Administered Inhaler', 'Medication'),
(3, 'General Consultation', 'Consultation');

INSERT INTO Drug_Dimension (Drug_ID, Name, Category, Cost, Stock_Level)
VALUES 
(1, 'Lisinopril', 'Antihypertensive', 0.50, 100),
(2, 'Albuterol Inhaler', 'Bronchodilator', 25.00, 50),
(3, 'Ibuprofen', 'Analgesic', 0.10, 500);

INSERT INTO Insurance_Dimension (Insurance_ID, Company_Name, Plan_Type, Coverage_Percentage)
VALUES 
(1, 'Blue Cross', 'Premium', 90.00),
(2, 'United Health', 'Standard', 80.00),
(3, 'Aetna', 'Basic', 70.00);

-- Select from Dimension Tables
SELECT * FROM Patient_Dimension;

SELECT * FROM Provider_Dimension;

SELECT * FROM Appointment_Dimension;

SELECT * FROM Diagnosis_Dimension;

SELECT * FROM Treatment_Dimension;

SELECT * FROM Drug_Dimension;

SELECT * FROM Insurance_Dimension;


