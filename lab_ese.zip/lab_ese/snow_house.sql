DROP database ass4;
create database ass4;
use ass4;
-- Tenant Dimension Table
CREATE TABLE Tenant_Dimension (
    tenant_id INT PRIMARY KEY AUTO_INCREMENT,
    tenant_name VARCHAR(100),
    tenant_contact VARCHAR(15),
    tenant_email VARCHAR(100),
    tenant_date_of_birth DATE
);

CREATE TABLE Property_Type_Dimension (
    property_type_id INT PRIMARY KEY AUTO_INCREMENT,
    property_type VARCHAR(50)
);

-- Property Dimension Table
CREATE TABLE Property_Dimension (
    property_id INT PRIMARY KEY AUTO_INCREMENT,
    property_name VARCHAR(100),
    property_type_id INT,
    bedrooms INT,
    bathrooms INT,
    square_feet INT,
    property_status VARCHAR(20),
    FOREIGN KEY (property_type_id) REFERENCES Property_Type_Dimension(property_type_id)
);


-- Owner Dimension Table
CREATE TABLE Owner_Dimension (
    owner_id INT PRIMARY KEY AUTO_INCREMENT,
    owner_name VARCHAR(100),
    owner_contact VARCHAR(15),
    owner_email VARCHAR(100)
);


-- Rental Agreement Dimension Table
CREATE TABLE Rental_Agreement_Dimension (
    rental_agreement_id INT PRIMARY KEY AUTO_INCREMENT,
    agreement_start_date DATE,
    agreement_end_date DATE,
    agreement_terms TEXT
);


-- Payment Dimension Table
CREATE TABLE Payment_Dimension (
    payment_id INT PRIMARY KEY AUTO_INCREMENT,
    payment_date DATE,
    payment_amount DECIMAL(10, 2),
    payment_method VARCHAR(50)
);

CREATE TABLE City_State_Dimension (
    city_state_id INT PRIMARY KEY AUTO_INCREMENT,
    city VARCHAR(100),
    state VARCHAR(100)
);

-- Location Dimension Table
CREATE TABLE Location_Dimension (
    location_id INT PRIMARY KEY AUTO_INCREMENT,
    city_state_id INT,
    zip_code VARCHAR(10),
    neighborhood VARCHAR(100),
    FOREIGN KEY (city_state_id) REFERENCES City_State_Dimension(city_state_id)
);


-- Rental Fact Table
CREATE TABLE Rental_Fact (
    rental_id INT PRIMARY KEY AUTO_INCREMENT,
    tenant_id INT,
    property_id INT,
    owner_id INT,
    rental_agreement_id INT,
    location_id INT,
    payment_id INT,
    rental_start_date DATE,
    rental_end_date DATE,
    rent_amount DECIMAL(10, 2),
    duration_in_months INT,
    FOREIGN KEY (tenant_id) REFERENCES Tenant_Dimension(tenant_id),
    FOREIGN KEY (property_id) REFERENCES Property_Dimension(property_id),
    FOREIGN KEY (owner_id) REFERENCES Owner_Dimension(owner_id),
    FOREIGN KEY (rental_agreement_id) REFERENCES Rental_Agreement_Dimension(rental_agreement_id),
    FOREIGN KEY (location_id) REFERENCES Location_Dimension(location_id),
    FOREIGN KEY (payment_id) REFERENCES Payment_Dimension(payment_id)
);


INSERT INTO Property_Type_Dimension (property_type)
VALUES
('Apartment'),
('House'),
('Condo');

INSERT INTO Property_Dimension (property_name, property_type_id, bedrooms, bathrooms, square_feet, property_status)
VALUES
('Sunrise Apartments', 1, 2, 1, 1200, 'Available'),
('Maple Villa', 2, 3, 2, 1600, 'Occupied'),
('Pine Grove Condos', 3, 2, 2, 1400, 'Available'),
('Willow Heights', 1, 1, 1, 800, 'Occupied'),
('Oakwood Mansion', 2, 5, 4, 3000, 'Available');

INSERT INTO City_State_Dimension (city, state)
VALUES
('New York', 'NY'),
('Los Angeles', 'CA'),
('Chicago', 'IL'),
('San Francisco', 'CA'),
('Houston', 'TX');

INSERT INTO Location_Dimension (city_state_id, zip_code, neighborhood)
VALUES
(1, '10001', 'Midtown'),
(2, '90001', 'Downtown'),
(3, '60601', 'The Loop'),
(4, '94101', 'Mission District'),
(5, '77001', 'Uptown');

INSERT INTO Tenant_Dimension (tenant_name, tenant_contact, tenant_email, tenant_date_of_birth)
VALUES
('John Doe', '123-456-7890', 'john.doe@example.com', '1985-06-15'),
('Jane Smith', '234-567-8901', 'jane.smith@example.com', '1990-09-22'),
('Alex Johnson', '345-678-9012', 'alex.johnson@example.com', '1982-03-10'),
('Emily Davis', '456-789-0123', 'emily.davis@example.com', '1995-11-12'),
('Michael Brown', '567-890-1234', 'michael.brown@example.com', '1979-12-01');

INSERT INTO Owner_Dimension (owner_name, owner_contact, owner_email)
VALUES
('Samuel Green', '789-123-4567', 'samuel.green@example.com'),
('Olivia White', '890-234-5678', 'olivia.white@example.com'),
('Henry Black', '901-345-6789', 'henry.black@example.com'),
('Sophia Blue', '012-456-7890', 'sophia.blue@example.com'),
('Benjamin Gray', '123-567-8901', 'benjamin.gray@example.com');

INSERT INTO Rental_Agreement_Dimension (agreement_start_date, agreement_end_date, agreement_terms)
VALUES
('2024-01-01', '2025-01-01', 'One year lease, no pets allowed.'),
('2023-06-01', '2024-06-01', 'One year lease, pets allowed with deposit.'),
('2024-03-15', '2025-03-15', 'One year lease, no smoking allowed.'),
('2024-08-01', '2025-08-01', 'One year lease, parking space included.'),
('2023-11-01', '2024-11-01', 'One year lease, utilities included.');

-- Tenant Dimension Table
SELECT * FROM Tenant_Dimension;

-- Property Type Dimension Table
SELECT * FROM Property_Type_Dimension;

-- Property Dimension Table
SELECT * FROM Property_Dimension;

-- Owner Dimension Table
SELECT * FROM Owner_Dimension;

-- Rental Agreement Dimension Table
SELECT * FROM Rental_Agreement_Dimension;

-- Payment Dimension Table
SELECT * FROM Payment_Dimension;

-- City State Dimension Table
SELECT * FROM City_State_Dimension;

-- Location Dimension Table
SELECT * FROM Location_Dimension;


